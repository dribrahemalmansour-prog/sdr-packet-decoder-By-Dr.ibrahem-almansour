import re
from typing import List


HEX_PAIR_RE = re.compile(r"[0-9a-fA-F]{2}")


def extract_hex_pairs(line: str) -> List[str]:
    """Extract hex byte pairs from a noisy SDR line."""
    return HEX_PAIR_RE.findall(line)
