from typing import List, Dict, Any

PREAMBLE = ["AA", "BB"]  # frame start marker


def hex_to_int(h: str) -> int:
    return int(h, 16)


def compute_checksum(payload: List[str]) -> int:
    return sum(hex_to_int(b) for b in payload) % 256


def decode_payload(payload: List[str]) -> str:
    try:
        raw = bytes(int(b, 16) for b in payload)
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return " ".join(payload)


def find_packets(stream: List[str]) -> List[Dict[str, Any]]:
    packets = []
    i = 0
    while i < len(stream):
        if stream[i : i + 2] == PREAMBLE and i + 3 < len(stream):
            length = hex_to_int(stream[i + 2])
            start_payload = i + 3
            end_payload = start_payload + length
            checksum_idx = end_payload
            if checksum_idx < len(stream):
                payload = stream[start_payload:end_payload]
                recv_checksum = hex_to_int(stream[checksum_idx])
                calc_checksum = compute_checksum(payload)
                if recv_checksum == calc_checksum:
                    packets.append(
                        {
                            "start_index": i,
                            "length": length,
                            "payload_hex": payload,
                            "payload_text": decode_payload(payload),
                            "checksum": recv_checksum,
                            "valid": True,
                        }
                    )
                    i = checksum_idx + 1
                    continue
        i += 1
    return packets
