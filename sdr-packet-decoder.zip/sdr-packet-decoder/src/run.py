import argparse
from pathlib import Path

from src.cleaner import extract_hex_pairs
from src.parser import find_packets


def main() -> None:
    parser = argparse.ArgumentParser(description="Decode packets from noisy SDR hex output.")
    parser.add_argument("--file", required=True, help="path to noisy hex log file")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        raise SystemExit(f"File not found: {path}")

    all_hex = []
    for line in path.read_text(encoding="utf-8").splitlines():
        all_hex.extend(extract_hex_pairs(line))

    packets = find_packets(all_hex)

    if not packets:
        print("No valid packets found.")
        return

    print(f"Found {len(packets)} valid packet(s):")
    for idx, pkt in enumerate(packets, 1):
        print(f"\nPacket {idx}:")
        print(f"  start_index: {pkt['start_index']}")
        print(f"  length     : {pkt['length']} bytes")
        print(f"  payload_hex: {' '.join(pkt['payload_hex'])}")
        print(f"  payload_txt: {pkt['payload_text']}")
        print(f"  checksum   : 0x{pkt['checksum']:02X}")
        print(f"  valid      : {pkt['valid']}")
        print("  ----")


if __name__ == "__main__":
    main()
